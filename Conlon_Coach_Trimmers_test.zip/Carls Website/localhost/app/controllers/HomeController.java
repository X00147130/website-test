package controllers;

import play.mvc.*;
import play.mvc.Http.*;
import play.mvc.Http.MultipartFormData.FilePart;
import java.io.File;
import java.io.IOException;
import java.awt.image.*;
import javax.imageio.*;
import org.imgscalr.*;
import views.html.*;
import play.api.Environment;
import play.data.*;
import play.db.ebean.Transactional;

import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;

import models.*;


public class HomeController extends Controller {

    
    private FormFactory formFactory;
    private Environment e;
    @Inject
    public HomeController(FormFactory f, Environment env){
        this.e = env;
        this.formFactory=f;
    }


    public Result index() {
        return ok(index.render(User.getUserById(session().get("email"))));
    }

    public Result Coaches() {
        return ok(Coaches.render(User.getUserById(session().get("email"))));
     }
    
    public Result Gallery() {
        return ok(Gallery.render(itemForm,User.getUserById(session().get("email"))));
    }

    public Result TrucksAndVans(){
        return ok(TrucksAndVans.render(itemform,User.getUserById(session().get("email"))));
    }
   
}
